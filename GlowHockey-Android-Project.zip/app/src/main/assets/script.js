const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const startScreen = document.getElementById("startScreen");
const puckScreen = document.getElementById("puckScreen");
const gameScreen = document.getElementById("gameScreen");
const gameOver = document.getElementById("gameOver");

const computerMode = document.getElementById("computerMode");
const twoPlayerMode = document.getElementById("twoPlayerMode");
const startGameBtn = document.getElementById("startGameBtn");
const backBtn = document.getElementById("backBtn");

const restartBtn = document.getElementById("restart-btn");
const restartGame = document.getElementById("restart-game");
const pauseBtn = document.getElementById("pause-btn");
const menuBtn = document.getElementById("menu-btn");
const gameOverMenu = document.getElementById("gameOverMenu");

const aiScoreText = document.getElementById("aiScore");
const playerScoreText = document.getElementById("playerScore");

const topPlayerName = document.getElementById("topPlayerName");
const bottomPlayerName = document.getElementById("bottomPlayerName");

const winnerText = document.getElementById("winnerText");
const gameStatus = document.getElementById("gameStatus");


/* =========================
   GAME VARIABLES
========================= */

let gameMode = "computer";

let paused = false;
let gameRunning = false;

let playerScore = 0;
let opponentScore = 0;

const WIN_SCORE = 7;

let width;
let height;

let selectedPuckColor = "#ffffff";

let puck;
let bottomPaddle;
let topPaddle;


/*
    Who must serve?

    "bottom" = Player 1
    "top"    = Computer / Player 2
*/

let servingPlayer = "bottom";


/* =========================
   PUCK SELECTION
========================= */

const puckChoices =
    document.querySelectorAll(".puck-choice");

puckChoices.forEach(choice => {

    choice.addEventListener("click", () => {

        puckChoices.forEach(item => {
            item.classList.remove("selected");
        });

        choice.classList.add("selected");

        selectedPuckColor =
            choice.dataset.color;
    });

});


/* =========================
   RESIZE
========================= */

function resizeCanvas() {

    width = Math.min(
        window.innerWidth - 20,
        500
    );

    height = Math.min(
        window.innerHeight - 110,
        750
    );

    canvas.width = width;
    canvas.height = height;

    createGameObjects();
}

window.addEventListener(
    "resize",
    resizeCanvas
);


/* =========================
   GAME OBJECTS
========================= */

function createGameObjects() {

    bottomPaddle = {
        x: width / 2,
        y: height - 65,
        radius: 28
    };

    topPaddle = {
        x: width / 2,
        y: 65,
        radius: 28
    };

    puck = {
        x: width / 2,
        y: height / 2,
        radius: 13,
        vx: 0,
        vy: 0,
        moving: false
    };
}


/* =========================
   GAME MODE
========================= */

computerMode.addEventListener(
    "click",
    () => {

        gameMode = "computer";

        openPuckSelection();
    }
);


twoPlayerMode.addEventListener(
    "click",
    () => {

        gameMode = "twoPlayer";

        openPuckSelection();
    }
);


function openPuckSelection() {

    startScreen.classList.add("hidden");

    gameScreen.classList.add("hidden");

    puckScreen.classList.remove("hidden");
}


/* =========================
   START GAME
========================= */

startGameBtn.addEventListener(
    "click",
    startGame
);


function startGame() {

    puckScreen.classList.add("hidden");

    gameScreen.classList.remove("hidden");

    gameOver.classList.add("hidden");

    playerScore = 0;
    opponentScore = 0;

    paused = false;
    gameRunning = true;

    pauseBtn.textContent = "Pause";

    updateScore();


    if (gameMode === "computer") {

        topPlayerName.textContent =
            "COMPUTER";

    } else {

        topPlayerName.textContent =
            "PLAYER 2";
    }

    bottomPlayerName.textContent =
        "PLAYER 1";


    /*
        At the beginning of the match,
        Player 1 receives the puck.
    */

    servingPlayer = "bottom";

    prepareServe();


    gameStatus.textContent =
        "PLAYER 1: HIT THE PUCK!";


    setTimeout(() => {

        if (gameRunning) {
            gameStatus.textContent = "";
        }

    }, 2500);
}


/* =========================
   PREPARE SERVE
========================= */

function prepareServe() {

    puck.x = width / 2;

    /*
        Put puck close to the player
        who must serve.
    */

    if (servingPlayer === "bottom") {

        puck.y =
            height - 115;

    } else {

        puck.y = 115;
    }


    puck.vx = 0;
    puck.vy = 0;

    puck.moving = false;


    /*
        Computer automatically serves.
    */

    if (
        gameMode === "computer" &&
        servingPlayer === "top"
    ) {

        gameStatus.textContent =
            "COMPUTER IS SERVING...";

        setTimeout(() => {

            computerServe();

        }, 500);
    }
}


/* =========================
   PLAYER SERVE
========================= */

function playerServe() {

    if (
        servingPlayer !== "bottom" ||
        puck.moving ||
        !gameRunning ||
        paused
    ) {
        return;
    }


    /*
        Make sure the puck is near
        Player 1's paddle.
    */

    const dx =
        puck.x - bottomPaddle.x;

    const dy =
        puck.y - bottomPaddle.y;

    const distance =
        Math.sqrt(
            dx * dx +
            dy * dy
        );


    /*
        Player must actually hit
        the puck.
    */

    if (
        distance <=
        bottomPaddle.radius +
        puck.radius +
        15
    ) {

        const angle =
            Math.atan2(
                puck.y - bottomPaddle.y,
                puck.x - bottomPaddle.x
            );


        const speed = 5;


        puck.vx =
            Math.cos(angle) * speed;

        puck.vy =
            Math.sin(angle) * speed;


        /*
            If the hit direction is
            accidentally downward,
            force it upward.
        */

        if (puck.vy > -1) {
            puck.vy = -speed;
        }


        puck.moving = true;

        gameStatus.textContent = "";
    }
}


/* =========================
   COMPUTER SERVE
========================= */

function computerServe() {

    if (
        !gameRunning ||
        paused ||
        servingPlayer !== "top"
    ) {
        return;
    }


    /*
        Put computer paddle directly
        under/behind the puck.
    */

    topPaddle.x = puck.x;


    /*
        Hit toward Player 1.
    */

    puck.vx =
        (Math.random() - 0.5) * 3;

    puck.vy = 5;


    puck.moving = true;

    gameStatus.textContent = "";
}


/* =========================
   SCORE
========================= */

function updateScore() {

    playerScoreText.textContent =
        playerScore;

    aiScoreText.textContent =
        opponentScore;
}


/* =========================
   RESET PUCK AFTER GOAL
========================= */

function resetAfterGoal(nextServer) {

    servingPlayer = nextServer;

    prepareServe();


    if (
        servingPlayer === "bottom"
    ) {

        gameStatus.textContent =
            "PLAYER 1: HIT THE PUCK!";

    } else {

        if (gameMode === "computer") {

            gameStatus.textContent =
                "COMPUTER IS SERVING...";

        } else {

            gameStatus.textContent =
                "PLAYER 2: HIT THE PUCK!";
        }
    }
}


/* =========================
   DRAW TABLE
========================= */

function drawTable() {

    ctx.clearRect(
        0,
        0,
        width,
        height
    );


    ctx.fillStyle = "#080812";

    ctx.fillRect(
        0,
        0,
        width,
        height
    );


    /*
        Outer wall
    */

    ctx.strokeStyle = "#00ffff";

    ctx.lineWidth = 3;

    ctx.strokeRect(
        2,
        2,
        width - 4,
        height - 4
    );


    /*
        Center line
    */

    ctx.beginPath();

    ctx.moveTo(
        3,
        height / 2
    );

    ctx.lineTo(
        width - 3,
        height / 2
    );

    ctx.stroke();


    /*
        Center circle
    */

    ctx.beginPath();

    ctx.arc(
        width / 2,
        height / 2,
        55,
        0,
        Math.PI * 2
    );

    ctx.stroke();


    /*
        Goals
    */

    ctx.strokeRect(
        width / 2 - 70,
        0,
        140,
        12
    );

    ctx.strokeRect(
        width / 2 - 70,
        height - 12,
        140,
        12
    );
}


/* =========================
   DRAW PADDLE
========================= */

function drawPaddle(
    paddle,
    playerColor
) {

    const gradient =
        ctx.createRadialGradient(
            paddle.x,
            paddle.y,
            2,
            paddle.x,
            paddle.y,
            paddle.radius
        );


    gradient.addColorStop(
        0,
        "#ffffff"
    );

    gradient.addColorStop(
        0.3,
        playerColor
    );

    gradient.addColorStop(
        1,
        "#111111"
    );


    ctx.beginPath();

    ctx.arc(
        paddle.x,
        paddle.y,
        paddle.radius,
        0,
        Math.PI * 2
    );


    ctx.fillStyle = gradient;

    ctx.shadowBlur = 20;

    ctx.shadowColor =
        playerColor;

    ctx.fill();

    ctx.shadowBlur = 0;
}


/* =========================
   DRAW PUCK
========================= */

function drawPuck() {

    ctx.beginPath();

    ctx.arc(
        puck.x,
        puck.y,
        puck.radius,
        0,
        Math.PI * 2
    );


    ctx.fillStyle =
        selectedPuckColor;

    ctx.shadowBlur = 25;

    ctx.shadowColor =
        selectedPuckColor;

    ctx.fill();

    ctx.shadowBlur = 0;
}


/* =========================
   PADDLE COLLISION
========================= */

function paddleCollision(paddle) {

    const dx =
        puck.x - paddle.x;

    const dy =
        puck.y - paddle.y;

    const distance =
        Math.sqrt(
            dx * dx +
            dy * dy
        );


    if (
        distance <
        puck.radius +
        paddle.radius
    ) {

        const angle =
            Math.atan2(dy, dx);


        const speed =
            Math.sqrt(
                puck.vx * puck.vx +
                puck.vy * puck.vy
            ) + 0.15;


        puck.vx =
            Math.cos(angle) * speed;

        puck.vy =
            Math.sin(angle) * speed;


        const overlap =
            puck.radius +
            paddle.radius -
            distance;


        puck.x +=
            Math.cos(angle) *
            overlap;

        puck.y +=
            Math.sin(angle) *
            overlap;
    }
}


/* =========================
   COMPUTER AI
========================= */

function moveComputer() {

    /*
        Computer follows puck
        only when puck is moving.
    */

    if (!puck.moving) {

        /*
            During serve, move directly
            to the puck.
        */

        if (
            servingPlayer === "top"
        ) {

            topPaddle.x =
                puck.x;
        }

        return;
    }


    const difference =
        puck.x - topPaddle.x;


    topPaddle.x +=
        difference * 0.055;


    topPaddle.x =
        Math.max(
            topPaddle.radius,
            Math.min(
                width -
                topPaddle.radius,
                topPaddle.x
            )
        );
}


/* =========================
   PUCK MOVEMENT
========================= */

function updatePuck() {

    /*
        IMPORTANT:

        If puck.moving is false,
        it does NOT move.
    */

    if (!puck.moving) {
        return;
    }


    puck.x += puck.vx;

    puck.y += puck.vy;


    /*
        LEFT WALL
    */

    if (
        puck.x - puck.radius <= 3
    ) {

        puck.x =
            puck.radius + 3;

        puck.vx =
            Math.abs(puck.vx);
    }


    /*
        RIGHT WALL
    */

    if (
        puck.x + puck.radius >=
        width - 3
    ) {

        puck.x =
            width -
            puck.radius -
            3;

        puck.vx =
            -Math.abs(puck.vx);
    }


    const goalLeft =
        width / 2 - 70;

    const goalRight =
        width / 2 + 70;


    /*
        TOP
    */

    if (
        puck.y - puck.radius <= 3
    ) {

        /*
            Is it inside the goal?
        */

        if (
            puck.x >= goalLeft &&
            puck.x <= goalRight
        ) {

            /*
                PLAYER 1 SCORES

                Computer receives puck.
            */

            playerScore++;

            updateScore();


            if (
                playerScore >= WIN_SCORE
            ) {

                endGame(
                    "PLAYER 1 WINS!"
                );

                return;
            }


            resetAfterGoal("top");

            return;

        } else {

            /*
                Normal wall bounce.
            */

            puck.y =
                puck.radius + 3;

            puck.vy =
                Math.abs(puck.vy);
        }
    }


    /*
        BOTTOM
    */

    if (
        puck.y + puck.radius >=
        height - 3
    ) {

        if (
            puck.x >= goalLeft &&
            puck.x <= goalRight
        ) {

            /*
                COMPUTER / PLAYER 2 SCORES

                Player 1 receives puck.
            */

            opponentScore++;

            updateScore();


            if (
                opponentScore >= WIN_SCORE
            ) {

                if (
                    gameMode === "computer"
                ) {

                    endGame(
                        "COMPUTER WINS!"
                    );

                } else {

                    endGame(
                        "PLAYER 2 WINS!"
                    );
                }

                return;
            }


            resetAfterGoal("bottom");

            return;

        } else {

            /*
                Normal wall bounce.
            */

            puck.y =
                height -
                puck.radius -
                3;

            puck.vy =
                -Math.abs(puck.vy);
        }
    }


    /*
        PADDLE COLLISIONS
    */

    paddleCollision(
        bottomPaddle
    );

    paddleCollision(
        topPaddle
    );
}


/* =========================
   TOUCH CONTROL
========================= */

canvas.addEventListener(
    "pointermove",
    movePlayer
);

canvas.addEventListener(
    "pointerdown",
    movePlayer
);


function movePlayer(event) {

    if (
        !gameRunning ||
        paused
    ) {
        return;
    }


    const rect =
        canvas.getBoundingClientRect();


    const x =
        event.clientX -
        rect.left;

    const y =
        event.clientY -
        rect.top;


    /*
        PLAYER 1
    */

    if (
        y > height / 2
    ) {

        bottomPaddle.x =
            Math.max(
                bottomPaddle.radius,
                Math.min(
                    width -
                    bottomPaddle.radius,
                    x
                )
            );


        bottomPaddle.y =
            Math.max(
                height / 2 + 30,
                Math.min(
                    height -
                    bottomPaddle.radius,
                    y
                )
            );


        /*
            If Player 1 has the serve,
            check whether they hit it.
        */

        if (
            servingPlayer === "bottom" &&
            !puck.moving
        ) {

            playerServe();
        }
    }


    /*
        PLAYER 2
    */

    if (
        gameMode === "twoPlayer" &&
        y < height / 2
    ) {

        topPaddle.x =
            Math.max(
                topPaddle.radius,
                Math.min(
                    width -
                    topPaddle.radius,
                    x
                )
            );


        topPaddle.y =
            Math.max(
                topPaddle.radius,
                Math.min(
                    height / 2 - 30,
                    y
                )
            );


        /*
            Player 2 can serve.
        */

        if (
            servingPlayer === "top" &&
            !puck.moving
        ) {

            player2Serve();
        }
    }
}


/* =========================
   PLAYER 2 SERVE
========================= */

function player2Serve() {

    const dx =
        puck.x - topPaddle.x;

    const dy =
        puck.y - topPaddle.y;

    const distance =
        Math.sqrt(
            dx * dx +
            dy * dy
        );


    if (
        distance <=
        topPaddle.radius +
        puck.radius +
       15
    ) {

        const angle =
            Math.atan2(
                puck.y - topPaddle.y,
                puck.x - topPaddle.x
            );


        const speed = 5;


        puck.vx =
            Math.cos(angle) * speed;

        puck.vy =
            Math.sin(angle) * speed;


        /*
            Force puck downward.
        */

        if (puck.vy < 1) {
            puck.vy = speed;
        }


        puck.moving = true;

        gameStatus.textContent = "";
    }
}


/* =========================
   GAME OVER
========================= */

function endGame(message) {

    gameRunning = false;

    winnerText.textContent =
        message;

    gameOver.classList.remove(
        "hidden"
    );
}


/* =========================
   RESTART
========================= */

restartBtn.addEventListener(
    "click",
    startGame
);


restartGame.addEventListener(
    "click",
    startGame
);


/* =========================
   PAUSE
========================= */

pauseBtn.addEventListener(
    "click",
    () => {

        paused = !paused;


        if (paused) {

            pauseBtn.textContent =
                "Resume";

            gameStatus.textContent =
                "PAUSED";

        } else {

            pauseBtn.textContent =
                "Pause";

            gameStatus.textContent = "";
        }
    }
);


/* =========================
   MENU
========================= */

menuBtn.addEventListener(
    "click",
    showMenu
);

gameOverMenu.addEventListener(
    "click",
    showMenu
);


function showMenu() {

    gameRunning = false;

    gameOver.classList.add(
        "hidden"
    );

    gameScreen.classList.add(
        "hidden"
    );

    puckScreen.classList.add(
        "hidden"
    );

    startScreen.classList.remove(
        "hidden"
    );
}


/* =========================
   GAME LOOP
========================= */

function gameLoop() {

    drawTable();


    if (
        gameRunning &&
        !paused
    ) {

        if (
            gameMode === "computer"
        ) {

            moveComputer();
        }


        updatePuck();
    }


    drawPaddle(
        topPaddle,
        "#ff3366"
    );


    drawPaddle(
        bottomPaddle,
        "#00ffff"
    );


    drawPuck();


    requestAnimationFrame(
        gameLoop
    );
}


/* =========================
   START
========================= */

resizeCanvas();

gameLoop();