# Glow Hockey Android Project

This project packages the supplied HTML/CSS/JavaScript Glow Hockey game as an Android WebView app.

Web files:
- app/src/main/assets/index.html
- app/src/main/assets/style.css
- app/src/main/assets/script.js

Application ID:
com.cobby.glowhockey

Version:
1.0 (versionCode 1)

The project still needs to be built with the Android SDK/Gradle toolchain to produce the final APK.
